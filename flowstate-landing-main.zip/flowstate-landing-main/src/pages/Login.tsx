import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { ArrowRight, Eye, EyeOff, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link } from "react-router-dom";

const socialStats = [
  { platform: "Instagram", icon: "IG", color: "bg-gradient-to-br from-pink-500 to-orange-400", followers: "12.4K", growth: "+340%" },
  { platform: "Twitter / X", icon: "𝕏", color: "bg-foreground text-background", followers: "8.2K", growth: "+180%" },
  { platform: "YouTube", icon: "▶", color: "bg-red-500", followers: "5.1K", growth: "+220%" },
];

const Login = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [activeIdx, setActiveIdx] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => setActiveIdx((p) => (p + 1) % 3), 2500);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen flex" style={{ background: "var(--gradient-hero)" }}>
      {/* Left panel */}
      <div className="hidden lg:flex lg:w-1/2 items-center justify-center relative overflow-hidden bg-muted/30">
        <div className="absolute top-20 right-20 w-64 h-64 rounded-full opacity-[0.08] blur-3xl bg-primary" />
        <div className="absolute bottom-32 left-16 w-48 h-48 rounded-full opacity-[0.06] blur-3xl bg-primary" />

        <div className="relative z-10 max-w-md px-12">
          <Link to="/" className="font-display text-2xl font-bold tracking-tight mb-10 block">
            <span className="gradient-text">Velocity</span>
          </Link>

          <h2 className="text-3xl font-extrabold leading-tight text-foreground mb-3">
            Welcome back to
            <br />
            the intelligence layer.
          </h2>
          <p className="text-muted-foreground text-base leading-relaxed mb-10">
            Your agents are waiting. Pick up right where you left off.
          </p>

          {/* Social media growth cards */}
          <div className="space-y-3 mb-8">
            {socialStats.map((s, i) => (
              <motion.div
                key={s.platform}
                initial={{ opacity: 0, x: -16 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.12, duration: 0.4 }}
                className={`flex items-center gap-4 rounded-xl px-5 py-4 transition-all duration-500 ${
                  i === activeIdx
                    ? "bg-card shadow-md border border-primary/15 scale-[1.02]"
                    : "bg-card/60 border border-border"
                }`}
              >
                <div className={`w-9 h-9 rounded-lg flex items-center justify-center text-sm font-bold text-primary-foreground ${s.color}`}>
                  {s.icon}
                </div>
                <div className="flex-1">
                  <div className="text-sm font-semibold text-foreground">{s.platform}</div>
                  <div className="text-xs text-muted-foreground">{s.followers} followers</div>
                </div>
                <div className="flex items-center gap-1 text-xs font-semibold text-primary">
                  <TrendingUp size={13} />
                  {s.growth}
                </div>
              </motion.div>
            ))}
          </div>

          {/* Growth summary */}
          <div className="bg-card rounded-xl p-5 border border-border shadow-sm">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-8 h-8 rounded-lg gradient-bg flex items-center justify-center">
                <TrendingUp size={16} className="text-primary-foreground" />
              </div>
              <div>
                <div className="text-sm font-bold text-foreground">Total Reach Growth</div>
                <div className="text-xs text-muted-foreground">Last 90 days</div>
              </div>
            </div>
            {/* Mini bar chart */}
            <div className="flex items-end gap-1.5 h-12">
              {[20, 35, 28, 45, 55, 48, 65, 72, 68, 85, 90, 100].map((h, i) => (
                <motion.div
                  key={i}
                  initial={{ height: 0 }}
                  animate={{ height: `${h}%` }}
                  transition={{ delay: 0.5 + i * 0.05, duration: 0.4 }}
                  className="flex-1 rounded-sm gradient-bg opacity-70"
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Right panel — form */}
      <div className="flex-1 flex items-center justify-center px-6 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md"
        >
          <Link to="/" className="lg:hidden font-display text-2xl font-bold tracking-tight mb-8 block">
            <span className="gradient-text">Velocity</span>
          </Link>

          <h1 className="text-3xl font-bold mb-2">Sign in</h1>
          <p className="text-muted-foreground mb-8">
            Don't have an account?{" "}
            <Link to="/signup" className="text-primary font-semibold hover:underline">Sign up</Link>
          </p>

          <form className="space-y-5" onSubmit={(e) => e.preventDefault()}>
            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">Email</label>
              <Input type="email" placeholder="you@example.com" className="h-12 bg-card border-border focus:ring-2 focus:ring-primary/20" />
            </div>
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-sm font-medium text-foreground">Password</label>
                <a href="#" className="text-xs text-primary hover:underline">Forgot password?</a>
              </div>
              <div className="relative">
                <Input type={showPassword ? "text" : "password"} placeholder="••••••••" className="h-12 bg-card border-border focus:ring-2 focus:ring-primary/20 pr-10" />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>
            <Button size="lg" className="w-full h-12 gradient-bg text-primary-foreground border-0 text-base">
              Sign In <ArrowRight size={18} className="ml-2" />
            </Button>
          </form>

          <div className="relative my-8">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-border" /></div>
            <div className="relative flex justify-center">
              <span className="bg-background px-4 text-xs text-muted-foreground uppercase tracking-wider">or continue with</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Button variant="outline" className="h-12">
              <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" /><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" /><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" /><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" /></svg>
              Google
            </Button>
            <Button variant="outline" className="h-12">
              <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24"><path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z" /></svg>
              Apple
            </Button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Login;
